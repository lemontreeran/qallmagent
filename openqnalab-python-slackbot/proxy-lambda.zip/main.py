import os
import json
import base64
import hmac
import hashlib
import time
import requests
from urllib.parse import parse_qs

# Read environment variables
SALESFORCE_ACCESS_TOKEN = os.environ['SALESFORCE_ACCESS_TOKEN']
SALESFORCE_INSTANCE_URL = os.environ['SALESFORCE_INSTANCE_URL']
SALESFORCE_DATA_RETRIEVER_ENDPOINT = os.environ.get('SALESFORCE_DATA_RETRIEVER_ENDPOINT', '/services/apexrest/AgentQuery/')
SLACK_SIGNING_SECRET = os.environ['SLACK_SIGNING_SECRET']

# Verify Slack signature
def verify_slack_request(headers, body):
    request_timestamp = headers.get('x-slack-request-timestamp')
    slack_signature = headers.get('x-slack-signature')

    if not request_timestamp or not slack_signature:
        print("Missing signature headers.")
        return False

    # Prevent replay attack (allow only 5 minutes)
    current_time = int(time.time())
    if abs(current_time - int(request_timestamp)) > 60 * 5:
        print("Request timestamp is too old.")
        return False

    sig_basestring = f"v0:{request_timestamp}:{body}".encode('utf-8')
    my_signature = 'v0=' + hmac.new(
        SLACK_SIGNING_SECRET.encode('utf-8'),
        sig_basestring,
        hashlib.sha256
    ).hexdigest()

    if hmac.compare_digest(my_signature, slack_signature):
        print("Slack request signature verified successfully.")
        return True
    else:
        print("Slack request signature mismatch.")
        return False

# Main Lambda handler
def lambda_handler(event, context):
    try:
        print('Incoming event:', json.dumps(event))

        headers = {k.lower(): v for k, v in event['headers'].items()}

        # ⚡ Decode body if base64 encoded
        if event.get('isBase64Encoded', False):
            body = base64.b64decode(event['body']).decode('utf-8')
        else:
            body = event['body']

        print('Decoded body:', body)

        # ⚡ Verify Slack request authenticity
        if not verify_slack_request(headers, body):
            return {
                "statusCode": 401,
                "body": "Slack verification failed"
            }

        # Parse Slack command
        parsed_body = parse_qs(body)
        command = parsed_body.get('command', [''])[0]
        text = parsed_body.get('text', [''])[0]

        print(f"Command: {command}, Text: {text}")

        if command != '/ask':
            return {
                "statusCode": 200,
                "body": "Unknown command"
            }

        query = text.strip()

        if not query:
            return {
                "statusCode": 200,
                "body": "Please provide a question after /ask"
            }

        # ⚡ Call Salesforce Apex API
        response = requests.post(
            f"{SALESFORCE_INSTANCE_URL}{SALESFORCE_DATA_RETRIEVER_ENDPOINT}",
            headers={
                "Authorization": f"Bearer {SALESFORCE_ACCESS_TOKEN}",
                "Content-Type": "application/json"
            },
            json={"query": query}
        )

        print('Salesforce response:', response.text)

        if response.status_code == 200:
            result = response.json()
            answer = result.get('answer', "Sorry, no answer found.")

            return {
                "statusCode": 200,
                "headers": {
                    "Content-Type": "application/json"
                },
                "body": json.dumps({
                    "response_type": "in_channel",
                    "text": f"💬 *Question:* {query}\n\n🧠 *Answer:* {answer}"
                })
            }
        else:
            return {
                "statusCode": 500,
                "body": "Salesforce API call failed: " + response.text
            }

    except Exception as e:
        print('Exception:', str(e))
        return {
            "statusCode": 500,
            "body": "Internal server error"
        }
